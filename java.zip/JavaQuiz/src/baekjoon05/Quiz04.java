package baekjoon05;

import java.util.Scanner;

public class Quiz04 {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		//char a = (char)scan.nextShort();
		
		char a = 65;
		System.out.println(a);
		
		
	}

}
