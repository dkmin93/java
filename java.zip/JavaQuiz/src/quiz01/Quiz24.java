package quiz01;

public class Quiz24 { //백준 5-1

}
