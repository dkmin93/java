package quiz17;

public class StringQuiz03 { // 백준 6-4
	
	public static void main(String[] args) {
		
		
		
		
	}

}
