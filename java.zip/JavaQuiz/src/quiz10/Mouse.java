package quiz10;

public class Mouse {

	public void info() {
		System.out.println("----마우스 정보----");
		System.out.println("from 미키마우스");
	}
}
