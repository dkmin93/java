package quiz06sol;

import java.util.Arrays;
import java.util.Scanner;

public class MainClass {
	
	public static void main(String[] args) {
		
		MyCart cart = new MyCart(400);
		
		
		cart.buy("tv");
		cart.buy("com");
		cart.buy("radio");
		
		
	}

}
