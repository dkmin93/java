package baekjoon01;

import java.util.Scanner;

public class Quiz08 {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		int y = scan.nextInt();
		
		System.out.println( y - 543 );
		
	}

}
