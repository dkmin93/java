package baekjoon01;

import java.util.Scanner;

public class Quiz11 {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		long A = scan.nextLong();
		long B = scan.nextLong();
		long C = scan.nextLong();
		
		System.out.println(A + B + C);
		
		scan.close();		
				
		
	}

}
