package baekjoon01;

import java.util.Scanner;

public class Quiz05 {
	
	public static void main(String[] args) {
	
	Scanner scan = new Scanner(System.in);	
		
	double A = scan.nextDouble();
	double B = scan.nextDouble();
	
	System.out.println( A / B );
		
		
		
		
	}

}
