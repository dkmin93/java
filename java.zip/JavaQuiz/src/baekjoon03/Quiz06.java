package baekjoon03;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class Quiz06 { //빠른 A+B 스캐너 사용안하기
	
	public static void main(String[] args) {
		
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out)); 
			
			
			//String input = br.readLine();
			int t = 
			for(int i = 1; i<=t; i++) {
				
				int a = 
						int b = 
						int input = a+b;
						
						bw.write(input);
						bw.flush();
			}
			
			
			
				
			//br.close();
			//bw.close();
	
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
	}

}
