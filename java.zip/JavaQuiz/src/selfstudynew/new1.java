package selfstudynew;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class new1 {

}


class Solution {
    public String solution(String my_string, String alp) {
        String answer = "";
        
        String[] arr = my_string.split("");
        
        for(int i = 0; i < arr.length; i++) {
        	if(alp.equals(arr[i])) {
        		arr[i] = arr[i].toUpperCase();
        	}
        }
        
        for(int i = 0; i < arr.length; i++) {
        	answer += arr[i];
        }
        
        return answer;
    }
}