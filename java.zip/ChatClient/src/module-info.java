/**
 * 
 */
/**
 * 
 */
module ChatClient {
}