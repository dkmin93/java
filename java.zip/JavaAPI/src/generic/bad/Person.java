package generic.bad;

public class Person {
	
	//제네릭이 없다면
	private Object obj;
	
	public void setObj(Object obj) {
		this.obj = obj;
	}

	public Object getObj() {
		return obj;
	}
	
}
