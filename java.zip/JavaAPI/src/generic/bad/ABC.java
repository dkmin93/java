package generic.bad;

public class ABC {
	
	

}
