package ramda.anomymous.basic;

public interface RemoteControl {
	void turnOn();
	void turnOff();
	void VolumeUp();
	void VolumeDown();
	 

}
