package ramda.anomymous.basic;

public class Tv {

	private int sound;
	private RemoteControl = RemoteControl();
	
}
