package ramda.basic;

public interface Say01 {

	//추상 메서드가 1개인 인터페이스를 함수적 인터페이스로 쓸 수 있습니다.
	void talking();
	
	
}
