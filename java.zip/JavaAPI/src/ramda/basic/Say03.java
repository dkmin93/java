package ramda.basic;

public interface Say03 {

	String talking(String word, int i);
	
}
