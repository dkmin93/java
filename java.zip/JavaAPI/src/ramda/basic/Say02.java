package ramda.basic;

public interface Say02 {
	
	void talking(String word);

}
