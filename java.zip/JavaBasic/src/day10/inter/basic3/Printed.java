package day10.inter.basic3;

public interface Printed {

	//클래스가 가져야할 추상메서드 선언
	void print(String document);
	int copy(int n);
	
}
