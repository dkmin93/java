package day10.inter.basic1;

public interface Inter01 {

	//상수와 추상메서드를 가진다
	double PI= 3.14; //인터페이스에서 변수를 선언하면 상수 취급된다. final static이 없어도
	
	void method01(); //인터페이스에서 메서드를 선언하면 자동으로 추상메서드가 된다. abstract를 안 붙여도
	
	
}
