package day10.inter.basic4;

public interface Todo3 extends Todo1, Todo2 {

	void method03();
	
}
