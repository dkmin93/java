package day10.inter.basic4;

public interface Todo4 {

	void method04();
	
}
