package day10.inter.basic4;

public class MainClass {
	
	public static void main(String[] args) {
		
		
		
	}

}
