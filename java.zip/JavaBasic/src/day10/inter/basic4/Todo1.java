package day10.inter.basic4;

public interface Todo1 {

	//인터페이스 간에도 상속이 가능하다
	void method01();
}
