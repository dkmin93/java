package day10.inter.basic2;

public class Tiger extends Animal {

	public void eat() {
		System.out.println("호랑이는 사람고기를 먹어요");
	}

}
