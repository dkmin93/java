package day06;

public class VarMain {
	
	public static void main(String[] args) {
		
		Variable v = new Variable();
		
//		v.a = 100; // 멤버변수는 초기값을 지정하지 않아도 기본 값을 지닌다
		v.printNum(2);
		
	}

}
