package day09.poly.basic2;

public class House {
	
	//Student, Teacher, Employee를 전달 받아서 기능을 출력해주는 메서드
	public void showPerson(Person p) {
		System.out.println(p.info());  
	}
	
	
}
