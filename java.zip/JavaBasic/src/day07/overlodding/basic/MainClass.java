package day07.overlodding.basic;

import java.util.Arrays;

public class MainClass {
	
	public static void main(String[] args) {
		
		Basic b = new Basic(); // 객체부터 생성
		b.abc(1);
		b.abc(3.14);
		b.abc("a", 1);
		b.abc(1, "a");
		
		
	}

}
