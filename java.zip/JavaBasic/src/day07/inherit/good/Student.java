package day07.inherit.good;

//자식의 클래스 뒤에 extends + 부모클래스 를 사용하고 중복되는 부분을 수정한다
public class Student extends Person {

	String studentId;
	
}
