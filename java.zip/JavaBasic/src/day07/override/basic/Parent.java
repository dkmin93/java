package day07.override.basic;

public class Parent {

	void method01() {
		System.out.println("부모님의 1번 메서드 실행");
	}
	
	void method02() {
		System.out.println("부모님의 2번 메서드 실행");
	}
	
}
