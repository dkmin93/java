package day07.override.basic;

public class MainClass {
	
	public static void main(String[] args) {
		
		Child c = new Child();
		c.method01();
		c.method02();
		
	}

}
