package day08.encap.bad;

public class MainClass {
	
	public static void main(String[] args) {
		
		MyData me = new MyData();
		me.year = 2025;
		me.month = 13;
		me.day = 111;
		me.ssn = "이게 뭔데?";
		
		me.info();
		
		
		
		
	}

}
