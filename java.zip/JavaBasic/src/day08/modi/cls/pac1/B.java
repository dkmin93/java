package day08.modi.cls.pac1;

public class B {
	
	//default 클래스 - 같은패키지 안이라서 접근 가능
	A a = new A();
}
