package day01;

public class Hello {

	public static void main(String[] args) {
		
		// \n은 줄바꿈 입니다
		/*
		 * 여러줄 주석입니다
		 * 
		 */
		System.out.print("hello world!");
		System.out.print("\n아 집에 가고 싶다!\n오늘은 빨리가야지! ㅋㅋ");
		
		//숫자와 문자 : 문자는 ""안에 넣어줘야 한다
		 System.out.print("\n");
		 System.out.print(1);
		 System.out.print("\n");
		 System.out.print("1");
	}
}
