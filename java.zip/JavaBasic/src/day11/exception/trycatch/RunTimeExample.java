package day11.exception.trycatch;

public class RunTimeExample {

}
